# Download the helper library from https://www.twilio.com/docs/python/install
import os
import json
from twilio.rest import Client
import boto3
from boto3.dynamodb.conditions import Key

account_sid = "ACf8d0f691faa3c1557b9e901ade2450dc"
auth_token = os.environ["AUTH_TOKEN"]
NOTIFY_SERVICE_SID = os.environ['TWILIO_NOTIFY_SERVICE_SID']
HAVING_CLASS_NOTIF = os.environ['HAVING_CLASS_NOTIF']
CLASS_CANCELED_NOTIF = os.environ['CLASS_CANCELED_NOTIF']
client = Client(account_sid, auth_token)

dynamodb = boto3.resource('dynamodb', region_name='us-east-1')
table = dynamodb.Table('BHCC-Classes')

def send_bulk_sms(items):
    items = items["Items"]
    print(items)
    bindings = list(map(lambda item: json.dumps({'binding_type': 'sms', 'address': item["phoneNumber"]}), items))
    print("=====> To Bindings :>", bindings, "<: =====")
    notification = client.notify.services(NOTIFY_SERVICE_SID).notifications.create(
        to_binding=bindings,
        body=CLASS_CANCELED_NOTIF
    )
    print(notification.body)

def lambda_handler(event, context):
    items = table.query(
        # Add the name of the index you want to use in your query.
        IndexName="class-phoneNumber-index",
        KeyConditionExpression=Key('class').eq('Web Development/Deploymemnt'),
    )

    send_bulk_sms(items)


    # for item in items:
    #     print(item)
    #     message = client.messages \
    #         .create(
    #             messaging_service_sid="MG45acffaa2d197a1d256f9f4372c0a58e",
    #             body="Reminder that there is Web Development class this evening at 6 pm at the Berwyn Heights Community Center. See you there!",
    #             to=f'+12403709092'
    #         )
        
    #     print(message.sid)